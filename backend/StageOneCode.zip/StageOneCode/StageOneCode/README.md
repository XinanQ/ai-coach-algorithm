# StageOneCode 使用说明 V1.0
日期：2026年5月27日
负责人： 李家慧 蒋子涵
当前是**框架阶段**：实体类在 `com.entity`，
目前应能看到 **6 张表**：`employees`、`organizations`、`projects`、`tasks`、`indicators`、`task_results`
## 一、解压后应看到的文件
```
StageOneCode/
├── README.md                        # 本说明文档（使用教程）
├── pom.xml                          # Maven 项目配置、依赖
├── mvnw                             # Mac/Linux 用 Maven 脚本
├── mvnw.cmd                         # Windows 用 Maven 脚本
├── .mvn/
│   └── wrapper/
│       └── maven-wrapper.properties # Maven Wrapper 配置
├── .gitignore                       # Git 忽略规则（可选）
├── .gitattributes                   # Git 属性（可选）
├── HELP.md                          # Spring Boot 说明（可选）
│
└── src/
    ├── main/
    │   ├── java/
    │   │   └── com/
    │   │       ├── bank/
    │   │       │   └── stageonecode/
    │   │       │       └── StageOneCodeApplication.java   # 主启动类（运行入口）
    │   │       │
    │   │       └── entity/                                # 实体类（对应数据库表）
    │   │           ├── Employee.java        → employees
    │   │           ├── Organization.java    → organizations
    │   │           ├── Project.java         → projects
    │   │           ├── Task.java            → tasks
    │   │           ├── Indicator.java       → indicators
    │   │           └── TaskResult.java      → task_results
    │   │
    │   └── resources/
    │       └── application.properties       # 数据库连接、端口等（需改密码）
    │
    └── test/
        └── java/
            └── com/bank/stageonecode/
                └── StageOneCodeApplicationTests.java      # 测试类（可选运行）
```
## 二、需要提前安装的软件

1. **JDK 21**（项目使用的是 Java 21）
2. **MySQL**（安装后记得启动服务）
3. **IntelliJ IDEA**（推荐Ultimate版本）
---

## 三、需要修改的地方（重要）
打开文件：
`src/main/resources/application.properties`
找到下面两行
```properties
spring.datasource.username=root
spring.datasource.password=请改成你的MySQL密码
```
把 `yourMySQLPassword` 换成你本机 MySQL 的真实密码。
其他配置一般不用改（数据库名 `stage_one`，端口 `8081`）。

---
## 四、创建数据库（只需做一次）

打开终端，登录 MySQL：
```bash
mysql -u root -p
```
输入你的 MySQL 密码后，执行：
```sql
CREATE DATABASE IF NOT EXISTS stage_one;
exit;
```
---
## 五、运行方式
1. 打开 IDEA → **File → Open** → 选择解压后的项目文件夹（里面有 `pom.xml` 的那一层）
2. 等待右下角 Maven 导入完成（第一次可能较慢，要下载依赖）
3. 确认 JDK 为 21：**File → Project Structure → Project → SDK**
4. 打开文件：  
   `src/main/java/com/bank/stageonecode/StageOneCodeApplication.java`
5. 点击类名旁边的绿色三角 **Run**
6. 控制台出现 **`Started StageOneCodeApplication`** 表示启动成功

## 六、验证是否跑通
1. **看启动日志**：没有红色报错，且有 `Started StageOneCodeApplication`
2. 打开终端，输入 mysql -u root -p 
3. 输入MYSQL密码后依次执行
```
USE stage_one;
SHOW TABLES;
```
目前应能看到 **6 张表**：`employees`、`organizations`、`projects`、`tasks`、`indicators`、`task_results`。

表是程序**第一次启动成功后自动创建**的，不需要手写 SQL。

---

## 七、常见问题

| 现象 | 处理 |
|------|------|
| Access denied for user 'root' | `application.properties` 密码没改对 |
| Unknown database 'stage_one' | 没执行上面的 `CREATE DATABASE` |
| Port 8081 was already in use | 关掉已运行的项目，或把 `server.port` 改成 8082 |
| 没有绿色运行按钮 | 确认打开的是含 `pom.xml` 的根目录，等 Maven 导入完成 |
| 每次重启数据没了 | 当前是 `ddl-auto=create`，会重建表；有数据后我们再统一改配置 |

---

