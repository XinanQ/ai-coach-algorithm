package com.bank.stageonecode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication(scanBasePackages = {"com.bank.stageonecode", "com.entity"})
@EntityScan("com.entity")
public class StageOneCodeApplication {

    public static void main(String[] args) {
        SpringApplication.run(StageOneCodeApplication.class, args);
    }

}
